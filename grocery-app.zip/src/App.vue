<template>
   <router-view/>
</template>

<style>
 #app {
        text-align: center;
       margin-top: 60px;
  } 
  
  .button {
    background-color: #4CAF50; 
    border: none;
    color: white;
    padding: 10px 15px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
  }
  
  .button2 {background-color: #008CBA;} 
  .button3 {background-color: #f44336;}  
  

</style>
