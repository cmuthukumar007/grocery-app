export const localstoragekeys = {
    productList:"Products"
}