import { createRouter, createWebHistory, RouteRecordRaw } from 'vue-router'
import Listview from '../views/ListView.vue'
import AddView from '../views/AddView.vue'

const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    name: 'home',
    component: Listview
  },
  {
    path: '/add',
    name: 'add',    
    component: AddView
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
